<?php
define("EW_REPORT_TABLE_PREFIX", "||PHPReportMaker||", TRUE);
define("EW_REPORT_LANGUAGE_FOLDER", "phprptlang/", TRUE);
?>
