<?php
	$config['webpassword'] = 'ngethe';
	$config['254705657582'] = array(
    'fromNumber' => '254705657582',
    'nick' => "cfmsaf",
    'waPassword' => "xN7VzZryY1PXaYXJ2U5exnkesQ0=",
	'id' => "%f4%01%d4t%12%87%9f0%3a%d1%80%bf%b0%ab%f0%96%8a%c9%2b%d6"
);
require 'src/whatsprot.class.php';
$whatsapp = new Whatsapp($config);
$whatsapp->updateStatus();
class Whatsapp
{
    private $config;
    private $from;
    private $number;
    private $id;
    private $nick;
    private $password;
    private $contacts = array();
    private $inputs;
    private $messages;
    private $wa;
    private $connected;
    private $waGroupList;
    public function __construct(array $config)
    {
        $this->config = $config;
            try {
          			$this->number = "254705657582";
                        $this->id = "%f4%01%d4t%12%87%9f0%3a%d1%80%bf%b0%ab%f0%96%8a%c9%2b%d6";
                        $this->nick = "airtel";
                        $this->password = "xN7VzZryY1PXaYXJ2U5exnkesQ0=";
						 $this->wa = new WhatsProt($this->number, $this->id, $this->nick, true);
						$this->wa->eventManager()->bind('onConnect', array($this, 'connected'));
$this->updateStatus();						
            } catch (Exception $e) {
                exit(json_encode(array(
                    "success" => false,
                    'type' => 'contacts',
                    "errormsg" => $e->getMessage()
                )));
} }
    public function connected()
    {
        $this->connected = true;
    }
    public function __destruct()
    {
        if (isset($this->wa) && $this->connected) {
            $this->wa->disconnect();
        }
    }
    private function connectToWhatsApp()
    {
        if (isset($this->wa)) {
            $this->wa->connect();
            $this->wa->loginWithPassword($this->password);
            return true;
        }
        return false;
    }
	public function updateStatus()
    {
            $this->connectToWhatsApp();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mywhatsa_what";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT status,profile_pix FROM status where phonenumber like '254705657582'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
	$status = $row["status"];
	$profile_pix = $row["profile_pix"];
	}
}
            $this->wa->sendStatusUpdate($status);
            $this->wa->sendSetProfilePicture($profile_pix);
    }
}
